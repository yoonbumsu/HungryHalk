package com.example.hungrytalk;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BottomNavi extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;//바텀내비게이션 뷰
    private FragmentManager fm;
    private FragmentTransaction ft;
    private ProfileFragment profileFragment;
    private Location location;
    private Chatroom chatroom;
    private Option option;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);
        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame,new ProfileFragment()).commit();

        bottomNavigationView  = findViewById(R.id.bottomNavi);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
               switch(menuItem.getItemId()){
                   case R.id.action_profile:
                       setFrag(0);
                       break;
                   case R.id.action_chatroom:
                       setFrag(1);
                       break;
                   case R.id.action_location:
                       setFrag(2);
                       break;
                   case R.id.action_option:
                       setFrag(3);
                       break;
               }

                return true;
            }
        });

        profileFragment = new ProfileFragment();
        location = new Location();
        option = new Option();
        chatroom = new Chatroom();
        setFrag(0); //첫 프래그먼트 무엇으로 지정해줄것인지
    }
    // 프래그먼트 교체 일어나는 실행문
    private  void setFrag(int n){
        fm =getSupportFragmentManager();
        ft =fm.beginTransaction();
        switch (n){
            case 0:
                ft.replace(R.id.main_frame, profileFragment);
                ft.commit();
                break;
            case 1:
                ft.replace(R.id.main_frame,chatroom);
                ft.commit();
                break;
            case 2:
                ft.replace(R.id.main_frame,location);
                ft.commit();
                break;
            case 3:
                ft.replace(R.id.main_frame,option);
                ft.commit();
                break;
        }
    }
}
