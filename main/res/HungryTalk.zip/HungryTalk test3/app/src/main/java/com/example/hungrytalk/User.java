package com.example.hungrytalk;

public class User {
    String email;
    String Username;
    String profileImageUrl;

        public String getEmail() {
            return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String getUsername() {
        return  Username;
    }

    public void Username(String Username) {
        this.Username = Username;
    }
    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

}
