package com.example.hungrytalk;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class Memberinfoactivity extends AppCompatActivity {
    private static final String TAG = "Memberinfoactivity";
    private ImageView profileImageView;
    private  String profilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        profileImageView =findViewById(R.id.profileimageView);
        findViewById(R.id.profileimageView).setOnClickListener(onClickListener);
        findViewById(R.id.LoginButton).setOnClickListener(onClickListener);

    }


    @Override public void onBackPressed() {
        super.onBackPressed();
       finish(); }

       @Override
               public void onActivityResult(int requestCode,int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        switch (requestCode){
            case 0 : {
                if (resultCode == Activity.RESULT_OK){
                    profilePath  = data .getStringExtra("profilePath");
                    Log.e("로그","profilePath"+profilePath);
                    Bitmap bmp = BitmapFactory.decodeFile(profilePath);
                    profileImageView.setImageBitmap(bmp);
                }
                break;
            }
        }
       }
    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.LoginButton:
                    profileUpdate();
                    break;
                case R.id.profileimageView:
                    Intent in2= new Intent(Memberinfoactivity.this,CameraActivity.class);
                    startActivityForResult(in2,0);

                break;
            }
        }
    };

    private void profileUpdate() {
        final String name = ((EditText) findViewById(R.id.editname)).getText().toString();
        final String phoneNumber = ((EditText) findViewById(R.id.editnumber)).getText().toString();
        final String date = ((EditText) findViewById(R.id.editdate)).getText().toString();
        final String address = ((EditText) findViewById(R.id.editaddress)).getText().toString();

        if(name.length() > 0){
        if (name.length() > 0 && phoneNumber.length() > 0 && date.length() > 0 && address.length() > 0) {
            FirebaseStorage storage = FirebaseStorage.getInstance().getInstance();
            StorageReference storageRef = storage.getReference();
           final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            final StorageReference mountainImagesRef = storageRef.child("users/"+ user.getUid() + "/profileImage.jpg");

            if(profilePath ==null){

                FirebaseFirestore db = FirebaseFirestore.getInstance();
                UserInfo memberInfo = new UserInfo(name, phoneNumber, date, address,toString());
                db.collection("users").document(user.getUid()).set(memberInfo)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(Memberinfoactivity.this, "회원정보 등록을 성공하였습니다.", Toast.LENGTH_SHORT).show();
                                Intent in3 = new Intent(Memberinfoactivity.this, BottomNavi.class);
                                startActivity(in3);
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(Memberinfoactivity.this, "회원정보 등록을 실패하였습니다.", Toast.LENGTH_SHORT).show();
                                Log.w(TAG, "Error adding document", e);
                            }


                        });


            }else {
                try {
                    InputStream stream = new FileInputStream(new File(profilePath));
                    UploadTask uploadTask = mountainImagesRef.putStream(stream);
                    uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                        @Override
                        public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                            if (!task.isSuccessful()) {

                                throw task.getException();

                            }

                            // Continue with the task to get the download URL
                            return mountainImagesRef.getDownloadUrl();
                        }
                    }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {
                            if (task.isSuccessful()) {
                                Uri  downloadUri  =task.getResult();


                                FirebaseFirestore db = FirebaseFirestore.getInstance();
                                UserInfo memberInfo = new UserInfo(name, phoneNumber, date, address,downloadUri.toString());
                                db.collection("users").document(user.getUid()).set(memberInfo)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Toast.makeText(Memberinfoactivity.this, "회원정보 등록을 성공하였습니다.", Toast.LENGTH_SHORT).show();
                                                Intent in3 = new Intent(Memberinfoactivity.this, Memberinfoactivity.class);
                                                startActivity(in3);
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(Memberinfoactivity.this, "회원정보 등록을 실패하였습니다.", Toast.LENGTH_SHORT).show();
                                                Log.w(TAG, "Error adding document", e);
                                            }


                                        });


                            } else {
                                Log.e("로그","실패");
                                Toast.makeText(Memberinfoactivity.this,"회원정보를 보내는데 실패하였습니다",Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }catch (FileNotFoundException e){
                    Log.e("로그","에러: "+e.toString());
                }
            }







            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                    .setDisplayName(name)
                    .build();

        } else {
            Toast.makeText(Memberinfoactivity.this, "회원정보를 입력해주세요.", Toast.LENGTH_LONG);
        }
    }



        }
}


